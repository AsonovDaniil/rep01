#pragma once

#include "person.h"

namespace functions {
	void save(Person* arr, const int& n);
	Person* load(int& n);
}
