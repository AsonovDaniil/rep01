#include <iostream>
#include <fstream>

#include "person.h"
#include "functions.h"

using namespace std;
using namespace functions;

int main() {
    int n{};
    cout << "n=";
    cin >> n;
    if (n < 1)
        return 0;

    Person * arr = new Person[n];
    for (int i = 0; i < n; i++) {
        string name;
        int age;
        cout << "name[" << i << "]=";
        cin >> name;
        cout << "age[" << i << "]=";
        cin >> age;
        arr[i].setName(name);
        arr[i].setAge(age);
    }

    cout << "1 - delete string 2 - add person 3 - edit 4-save 5-load 6-search\n";
    int l{};
    int a{};
    int b{};
    Person* arr2 = new Person[n - 1];
    Person* arr3 = new Person[n + 1];
    string name;
    int age;
    cin >> l;

    switch (l) {

    case 1:
        cout << "delete string a=";
        cin >> a;
        if (a<0 || a>n) {
            cout << "error a";
            return 0;
        }
        for (int i = 0; i < a; i++) {
            arr2[i].setName(arr[i].name());
            arr2[i].setAge(arr[i].age());
        }
        for (int j = a; j < n - 1; j++) {
            for (int i = a; i < n; i++) {
                arr2[j].setName(arr[i].name());
                arr2[j].setAge(arr[i].age());
            }
        }
        cout << "\nperson list:" << endl;
        for (int i = 0; i < n-1; i++) {
            cout << "name[" << i << "]=" << arr2[i].name() << endl;
            cout << "age[" << i << "]=" << arr2[i].age() << endl;
        }
        save(arr2, n);
        break;

    case 2:
        for (int i = 0; i < n; i++) {
            arr3[i].setName(arr[i].name());
            arr3[i].setAge(arr[i].age());
        }
        cout << "name[" << n << "]=";
        cin >> name;
        cout << "age[" << n << "]=";
        cin >> age;
        arr3[n].setName(name);
        arr3[n].setAge(age);
        cout << "\nperson list:" << endl;
        for (int i = 0; i < n + 1; i++) {
            cout << "name[" << i << "]=" << arr3[i].name() << endl;
            cout << "age[" << i << "]=" << arr3[i].age() << endl;
        }
        save(arr3, n);
        break;

    case 3:
        cout << "edit string a=";
        cin >> a;
        if (a<0 || a>n) {
            cout << "error a";
            return 0;
        }
        cout << "name[" << a << "]=";
        cin >> name;
        cout << "age[" << a << "]=";
        cin >> age;
        arr[a].setName(name);
        arr[a].setAge(age);
        cout << "\nperson list:" << endl;
        for (int i = 0; i < n; i++) {
            cout << "name[" << i << "]=" << arr[i].name() << endl;
            cout << "age[" << i << "]=" << arr[i].age() << endl;
        }
        save(arr, n);
        break;

    case 5:
        cout << "\nloading from txt file:" << endl;

        arr = load(n);
        cout << "loaded n=" << n << endl;
        if (!arr) {
            cout << "arr is null" << endl;
            return 0;
        }
        for (int i = 0; i < n; i++) {
            cout << "name[" << i << "]=" << arr[i].name() << endl;
            cout << "age[" << i << "]=" << arr[i].age() << endl;
        }
        break;
    case 6:
        cout << "age =";
        cin >> b;
        for (int i = 0; i < n; i++) {
            if (arr[i].age() == b) {
                cout << "age[" << i << "]=" << arr[i].age() << endl;
                cout << "name[" << i << "]=" << arr[i].name() << endl;
            }
        }
    }
    delete[] arr;
    delete[] arr2;
    delete[] arr3;
}